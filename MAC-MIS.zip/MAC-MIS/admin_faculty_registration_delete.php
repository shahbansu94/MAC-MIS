<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

$userid = $_GET['r_id'];

$sql = mysql_query("DELETE from user WHERE user_id = '$userid'");

if ($sql) {
    ?>
    <script type="text/javascript">
        alert("Deleted data successfully");
        window.location.href = 'admin_faculty_list.php';
    </script>
    <?php

} else {
    ?>
    <script type="text/javascript">
        alert('Could not delete data');
        window.location.href = 'admin_faculty_list.php';
    </script>
    <?php

}
?>

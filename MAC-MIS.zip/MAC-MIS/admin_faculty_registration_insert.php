<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

if (isset($_POST['btn-register'])) { // Has the image been uploaded?
    $uname = $_POST['username'];
    $fname = $_POST['firstname'];
    $lname = $_POST['lastname'];
    $email = $_POST['email'];
    $pwd = randomPassword();

    if ($db->isUserExisted($email)) {
        // user already exists
        ?>
        <script type="text/javascript">
            alert('Already Exists.');
        </script>
        <?php

    } else {

        $result = $db->insertFacultyData($uname, $fname, $lname, $email, $pwd);

        if (mysql_query($result)) {
            ?>
            <script type="text/javascript">
                window.location.href = 'admin_faculty_list.php';
            </script>
            <?php

        } else {
            ?>
            <script type="text/javascript">
                alert('error occured while inserting your data');
            </script>
            <?php

        }
    }
}

if (isset($_POST['btn-update'])) { // Has the image been uploaded?
    $uname = $_POST['username'];
    $fname = $_POST['firstname'];
    $lname = $_POST['lastname'];
    $email = $_POST['email'];
    $pwd = randomPassword();
    $userid = $_POST['userid'];

    $result = $db->updateFacultyData($uname, $fname, $lname, $email, $pwd, $userid);
    if (mysql_query($result)) {
        ?>
        <script type="text/javascript">
            window.location.href = 'admin_faculty_list.php';
        </script>
        <?php

    } else {
        ?>
        <script type="text/javascript">
            alert('error occured while updating your data');
        </script>
        <?php

    }
}
?>



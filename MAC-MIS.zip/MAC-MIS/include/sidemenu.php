<?php
include_once 'include/DB_Functions.php';
$users = new DB_Functions();
ini_set('max_execution_time', 3000);

$login_id = $_SESSION['login_id'];
$login_type = $_SESSION['login_type'];
?> 
<script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script type="text/javascript">
    $(function () {
        var userType = document.getElementById("userType").value;
        $("#userType").hide();
        if (userType === "1")
        {
            $("#staff").show();
            $("#student").hide();
            $("#faculty").hide();
        }
        if (userType === "2")
        {
            $("#faculty").show();
            $("#staff").hide();
            $("#student").hide();
        }
        if (userType === "3")
        {
            $("#student").show();
            $("#faculty").hide();
            $("#staff").hide();
        }

//        alert(userType);
    });

</script>
<input type="hidden" name="userType" id="userType" value=<?php echo $login_type; ?> >
<?php $page_id = basename($_SERVER['PHP_SELF']); ?>


<div id="student" class="sidebar responsive ace-save-state">
    <script type="text/javascript">
        try {
            ace.settings.loadState('sidebar')
        } catch (e) {
        }
    </script>

    <ul class="nav nav-list">
        <li class="active">
            <a class="<?php echo ($page_id == "dashboard.php" ? "active" : ""); ?>" href="dashboard.php">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Dashboard </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="">
            <a class="<?php echo ($page_id == "student_profile.php" ? "active" : ""); ?>" href="student_profile.php">
                <i class="menu-icon fa fa-pencil"></i>
                <span class="menu-text"> Profile </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="">
            <a class="<?php echo ($page_id == "student_job_list.php" ? "active" : ""); ?>" href="student_job_list.php">
                <i class="menu-icon fa fa-list"></i>
                <span class="menu-text"> Jobs </span>
            </a>

            <b class="arrow"></b>
        </li>
    </ul>    

    <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
        <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
    </div>

</div>

<div id="faculty" class="sidebar responsive ace-save-state">
    <script type="text/javascript">
        try {
            ace.settings.loadState('sidebar')
        } catch (e) {
        }
    </script>

    <ul class="nav nav-list">
        <li class="active">
            <a class="<?php echo ($page_id == "dashboard.php" ? "active" : ""); ?>" href="dashboard.php">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Dashboard </span>
            </a>

            <b class="arrow"></b>
        </li>

        <li class="">
            <a class="<?php echo ($page_id == "admin_student_list.php" ? "active" : ""); ?>" href="admin_student_list.php">
                <i class="menu-icon fa fa-caret-right"></i>
                Student
            </a>

            <b class="arrow"></b>
        </li>

        <li class="">
            <a class="<?php echo ($page_id == "report_student_job.php" ? "active" : ""); ?>" href="report_student_job.php">
                <i class="menu-icon fa fa-caret-right"></i>
                Student Job Details
            </a>

            <b class="arrow"></b>
        </li>

        <li class="">
            <a class="<?php echo ($page_id == "report_student_GPA.php" ? "active" : ""); ?>" href="report_student_GPA.php">
                <i class="menu-icon fa fa-caret-right"></i>
                Student GPA
            </a>

            <b class="arrow"></b>
        </li>

        <li class="">
            <a class="<?php echo ($page_id == "report_employers.php" ? "active" : ""); ?>" href="report_employers.php">
                <i class="menu-icon fa fa-caret-right"></i>
                Employer Details
            </a>

            <b class="arrow"></b>
        </li>
        <li class="">
            <a class="<?php echo ($page_id == "report_job_status.php" ? "active" : ""); ?>" href="report_job_status.php">
                <i class="menu-icon fa fa-caret-right"></i>
                Job Details
            </a>

            <b class="arrow"></b>
        </li>
    </ul>    

    <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
        <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
    </div>

</div>
<div id="staff" class="sidebar responsive ace-save-state">
    <script type="text/javascript">
        try {
            ace.settings.loadState('sidebar')
        } catch (e) {
        }
    </script>

    <ul class="nav nav-list">
        <li class="active">
            <a class="<?php echo ($page_id == "dashboard.php" ? "active" : ""); ?>" href="dashboard.php">
                <i class="menu-icon fa fa-tachometer"></i>
                <span class="menu-text"> Dashboard </span>
            </a>

            <b class="arrow"></b>
        </li>

        <li class="">
            <a class="dropdown-toggle">
                <i class="menu-icon fa fa-desktop"></i>
                <span class="menu-text">
                    Internship
                </span>

                <b class="arrow fa fa-angle-down"></b>
            </a>

            <b class="arrow"></b>

            <ul class="submenu">
                <li class="">
                    <a class="<?php echo ($page_id == "internship_company_list.php" ? "active" : ""); ?>" href="internship_company_list.php" class="dropdown-toggle">
                        <i class="menu-icon fa fa-caret-right"></i>

                        Company Details
                    </a>

                </li>

                <li class="">
                    <a class="<?php echo ($page_id == "internship_jobs_group.php" ? "active" : ""); ?>" href="internship_jobs_group.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Job Groups
                    </a>

                    <b class="arrow"></b>
                </li>

                <li class="">
                    <a class="<?php echo ($page_id == "internship_jobs.php" ? "active" : ""); ?>" href="internship_jobs.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Jobs
                    </a>

                    <b class="arrow"></b>
                </li>

                <li class="">
                    <a class="<?php echo ($page_id == "internship_student_job_list.php" ? "active" : ""); ?>" href="internship_student_job_list.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Student Internship Details
                    </a>

                    <b class="arrow"></b>
                </li>
            </ul>
        </li>

        <li class="">
            <a class="dropdown-toggle">
                <i class="menu-icon fa fa-list"></i>
                <span class="menu-text"> Administration </span>

                <b class="arrow fa fa-angle-down"></b>
            </a>

            <b class="arrow"></b>

            <ul class="submenu">
                <li class="">
                    <a class="<?php echo ($page_id == "admin_staff_list.php" ? "active" : ""); ?>" href="admin_staff_list.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Staff
                    </a>

                    <b class="arrow"></b>
                </li>

                <li class="">
                    <a class="<?php echo ($page_id == "admin_faculty_list.php" ? "active" : ""); ?>" href="admin_faculty_list.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Faculty
                    </a>

                    <b class="arrow"></b>
                </li>

                <li class="">
                    <a class="<?php echo ($page_id == "admin_student_list.php" ? "active" : ""); ?>" href="admin_student_list.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Student
                    </a>

                    <b class="arrow"></b>
                </li>
                <li class="">
                    <a class="<?php echo ($page_id == "admin_education_list.php" ? "active" : ""); ?>" href="admin_education_list.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Student Education
                    </a>

                    <b class="arrow"></b>
                </li>
                <li class="">
                    <a class="<?php echo ($page_id == "address_detail_list.php" ? "active" : ""); ?>" href="address_detail_list.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Student Address
                    </a>

                    <b class="arrow"></b>
                </li>
            </ul>
        </li>
        <li class="">
            <a class="<?php echo ($page_id == "student_details_upload.php" ? "active" : ""); ?>" href="student_details_upload.php">
                <i class="menu-icon fa fa-upload"></i>
                <span class="menu-text"> Student Data Upload </span>
            </a>

            <b class="arrow"></b>
        </li>
        <li class="">
            <a class="dropdown-toggle">
                <i class="menu-icon fa fa-list"></i>
                <span class="menu-text"> Reports </span>

                <b class="arrow fa fa-angle-down"></b>
            </a>

            <b class="arrow"></b>

            <ul class="submenu">
                <li class="">
                    <a class="<?php echo ($page_id == "report_student_job.php" ? "active" : ""); ?>" href="report_student_job.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Student Job Details
                    </a>

                    <b class="arrow"></b>
                </li>

                <li class="">
                    <a class="<?php echo ($page_id == "report_student_GPA.php" ? "active" : ""); ?>" href="report_student_GPA.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Student GPA
                    </a>

                    <b class="arrow"></b>
                </li>

                <li class="">
                    <a class="<?php echo ($page_id == "report_employers.php" ? "active" : ""); ?>" href="report_employers.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Employer Details
                    </a>

                    <b class="arrow"></b>
                </li>
                <li class="">
                    <a class="<?php echo ($page_id == "report_job_status.php" ? "active" : ""); ?>" href="report_job_status.php">
                        <i class="menu-icon fa fa-caret-right"></i>
                        Job Positions
                    </a>

                    <b class="arrow"></b>
                </li>
            </ul>
        </li>        
    </ul>    

    <div class="sidebar-toggle sidebar-collapse" id="sidebar-collapse">
        <i id="sidebar-toggle-icon" class="ace-icon fa fa-angle-double-left ace-save-state" data-icon1="ace-icon fa fa-angle-double-left" data-icon2="ace-icon fa fa-angle-double-right"></i>
    </div>
</div>



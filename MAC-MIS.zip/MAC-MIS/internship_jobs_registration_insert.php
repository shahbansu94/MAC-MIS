<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

if (isset($_POST['btn-register'])) {
    $job_grp = $_POST['job_group'];
    $job_cmp = $_POST['company'];
    $job_intType = $_POST['internship_type'];
    $job_position = $_POST['position'];
    $job_description = $_POST['description'];
    $job_salary = $_POST['salary'];
    $job_status = $_POST['status'];

    $job_resp = $_POST['responsibilities'];
    $rowCount_job_mail = count($_POST["users"]);
    $job_req = $_POST['requirements'];
    //$rowCount_job_req = count($_POST["chk_req"]);

    $result = $db->insertJobData($job_grp, $job_cmp, $job_intType, $job_position, $job_description, $job_salary, $job_status);

    $result_job_id = mysql_query("SELECT Max(job_details.job_id) as job_id FROM job_details");
    $data_job_id = mysql_fetch_array($result_job_id);
    $max_job_id = $data_job_id['job_id'];

    $result_job_resp = $db->insertJobResponsibility($job_resp, $max_job_id);
    $result_job_req = $db->insertJobRequirements($job_req, $max_job_id);
    //for ($i = 0; $i < $rowCount_job_mail; $i++) {
    //    $to = $_POST["student_email"][$i];
    //    require 'mailer/Send_Mail.php';
     //   $subject = "Test Mail";
     //   $body = "<div>" . $_POST["student_fname"] . "This is test..";
      //  Send_Mail($to, $subject, $body);
    //}

    if (mysql_query($result) && mysql_query($result_job_resp) && mysql_query($result_job_req)) {
        ?>
        <script type="text/javascript">
            alert('Inserted..');
            window.location.href = 'internship_jobs_registration.php';
        </script>
        <?php

    } else {
        ?>
        <script type="text/javascript">
            alert('error occured while inserting your data');
        </script>
        <?php

    }
}

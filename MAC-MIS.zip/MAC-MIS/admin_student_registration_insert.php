<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

if (isset($_POST['btn-register'])) { // Has the image been uploaded?
    $student_number = $_POST['student_number'];
    $student_fname = $_POST['student_fname'];
    $student_mname = $_POST['student_mname'];
    $student_lname = $_POST['student_lname'];
    $student_uname = $_POST['student_uname'];
    $student_email = $_POST['student_email'];
    $student_phone = $_POST['student_phone'];
    $student_gender = $_POST['student_gender'];
    $student_status = $_POST['student_status'];
    $student_current_past = $_POST['student_current_past'];
    $semester = $_POST['semester'];
    $semester_year = $_POST['semester_year'];
    $pwd = randomPassword();

    // check if patient already exists 
    if ($db->isStudentExisted($student_email)) {
        // user already exists
        ?>
        <script type="text/javascript">
            alert('Already Exists.');
        </script>
        <?php

    } else {

        $result = $db->insertStudentData($student_number, $student_fname, $student_mname, $student_lname, $student_uname, $student_email, $student_phone, $student_gender, $student_status, $student_current_past, $semester, $semester_year, $pwd);
        mysql_query($result);
        $sql_fetch = "SELECT student_id FROM student_details where student_email = '$student_email'";
        if (!( $selectRes = mysql_query($sql_fetch) )) {
            echo 'Retrieval of data from Database Failed - #' . mysql_errno() . ': ' . mysql_error();
        } else {
            if (mysql_num_rows($selectRes) == 0) {
                echo 'No Rows Returned';
            } else {
                
            }
            while ($row = mysql_fetch_assoc($selectRes)) {
                $student_id = $row['student_id'];
                $sql = "INSERT INTO semester_registered(semester,semester_year,student_id) VALUES('$semester','$semester_year','$student_id')";
                $sql_user = "INSERT INTO user(user_fname,user_lname,user_name,user_email,user_password,user_type_id) VALUES('$student_fname','$student_lname','$student_uname','$student_email','$pwd','3')";
                mysql_query($sql_user);
                if (mysql_query($sql)) {
                    ?>
                    <script type="text/javascript">
                        window.location.href = 'admin_student_list.php';
                    </script>
                    <?php

                } else {
                    ?>
                    <script type="text/javascript">
                        alert('error occured while inserting your data');
                    </script>
                    <?php

                }
            }
        }
    }
}

if (isset($_POST['btn-update'])) { // Has the image been uploaded?
    $student_id = $_POST['student_id'];
    $student_number = $_POST['student_number'];
    $student_fname = $_POST['student_fname'];
    $student_mname = $_POST['student_mname'];
    $student_lname = $_POST['student_lname'];
    $student_uname = $_POST['student_uname'];
    $student_email = $_POST['student_email'];
    $student_phone = $_POST['student_phone'];
    $student_gender = $_POST['student_gender'];
    $student_status = $_POST['student_status'];
    $student_current_past = $_POST['student_current_past'];
    $semester = $_POST['semester'];
    $semester_year = $_POST['semester_year'];

    $result = $db->updateStudentData($student_number, $student_fname, $student_mname, $student_lname, $student_uname, $student_phone, $student_gender, $student_status, $student_current_past, $student_id);
    mysql_query($result);
    $sql_fetch = "SELECT student_id FROM student_details where student_email = '$student_email'";
    if (!( $selectRes = mysql_query($sql_fetch) )) {
        echo 'Retrieval of data from Database Failed - #' . mysql_errno() . ': ' . mysql_error();
    } else {
        if (mysql_num_rows($selectRes) == 0) {
            echo 'No Rows Returned';
        } else {
            
        }
        while ($row = mysql_fetch_assoc($selectRes)) {
            $stu_id = $row['student_id'];
            $sql = "Update semester_registered set semester= '$semester', semester_year= '$semester_year' where student_id= '$stu_id'";
            $sql_user = "Update user set user_fname= '$student_fname',user_lname= '$student_lname',user_name= '$student_uname' where user_email= '$student_email'";
            mysql_query($sql_user);
            if (mysql_query($sql)) {
                ?>
                <script type="text/javascript">
                    window.location.href = 'admin_student_list.php';
                </script>
                <?php

            } else {
                ?>
                <script type="text/javascript">
                    alert('error occured while updating your data');
                </script>
                <?php

            }
        }
    }
}
?>



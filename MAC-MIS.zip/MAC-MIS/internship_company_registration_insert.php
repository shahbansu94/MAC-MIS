<?php

include_once 'include/DB_Functions.php';
$db = new DB_Functions();

if (isset($_POST['btn-register'])) {
    $company_name = $_POST['company_name'];
    $company_address = $_POST['company_address'];
    $company_city = $_POST['company_city'];
    $company_province = $_POST['company_province'];
    $company_postalcode = $_POST['company_postalcode'];
    $company_country = $_POST['company_country'];
    $company_contact_fname = $_POST['company_contact_fname'];
    $company_contact_lname = $_POST['company_contact_lname'];
    $company_contact_position = $_POST['company_contact_position'];
    $company_phone = $_POST['company_phone'];
    $company_email = $_POST['company_email'];
    $company_website = $_POST['company_website'];
    $company_notes = $_POST['company_notes'];

    $result = $db->insertCompanyData($company_name, $company_address, $company_city, $company_province, $company_postalcode, $company_country, $company_contact_fname, $company_contact_lname, $company_contact_position, $company_phone, $company_email, $company_website, $company_notes);
    if (mysql_query($result)) {
        ?>
        <script type="text/javascript">
            window.location.href = 'internship_company_list.php';
        </script>
        <?php

    } else {
        ?>
        <script type="text/javascript">
            alert('error occured while inserting your data');
        </script>
        <?php

    }
}

if (isset($_POST['btn-update'])) {
    $company_id = $_POST['company_id'];
    $company_name = $_POST['company_name'];
    $company_address = $_POST['company_address'];
    $company_city = $_POST['company_city'];
    $company_province = $_POST['company_province'];
    $company_postalcode = $_POST['company_postalcode'];
    $company_country = $_POST['company_country'];
    $company_contact_fname = $_POST['company_contact_fname'];
    $company_contact_lname = $_POST['company_contact_lname'];
    $company_contact_position = $_POST['company_contact_position'];
    $company_phone = $_POST['company_phone'];
    $company_email = $_POST['company_email'];
    $company_website = $_POST['company_website'];
    $company_notes = $_POST['company_notes'];

    $result = $db->updateCompanyData($company_id,$company_name, $company_address, $company_city, $company_province, $company_postalcode, $company_country, $company_contact_fname, $company_contact_lname, $company_contact_position, $company_phone, $company_email, $company_website, $company_notes);
    if (mysql_query($result)) {
        ?>
        <script type="text/javascript">
            window.location.href = 'internship_company_list.php';
        </script>
        <?php

    } else {
        ?>
        <script type="text/javascript">
            alert('error occured while updating your data');
        </script>
        <?php

    }
}
?>


